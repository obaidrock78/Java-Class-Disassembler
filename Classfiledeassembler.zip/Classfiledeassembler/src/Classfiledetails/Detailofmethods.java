
package Classfiledetails;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class Detailofmethods {
    short 		accessFlags;
    ConstantInfo 	name;
    ConstantInfo 	signature;
    Artibutedetail	attributes[];

    /**
     * Read a method data from the class file
     * @param ws
     * @param vb
     * @return 
     * @throws java.io.IOException 
     */
    public boolean read(DataInputStream ws, ConstantInfo vb[])
	throws IOException {
	int	count;

	accessFlags = ws.readShort();
	name = vb[ws.readShort()];
	signature = vb[ws.readShort()];
	count = ws.readShort();
	if (count != 0) {
	    attributes = new Artibutedetail[count];
	    for (int i = 0; i < count; i++) {
		attributes[i] = new Artibutedetail(); 
		if (! attributes[i].read(ws, vb)) {
		    return (false);
		}
	    }
	}
	return (true);
    }

    
     // Write out a methoddata,make constant table accordingly
     
    public void write(DataOutputStream dos, ConstantInfo pool[])
	throws IOException, Exception {
	dos.writeShort(accessFlags);
	dos.writeShort(ConstantInfo.indexOf(name, pool));
	dos.writeShort(ConstantInfo.indexOf(signature, pool));
	if (attributes == null) {
	    dos.writeShort(0);
	} else {
	    dos.writeShort(attributes.length);
            for (Artibutedetail attribute : attributes) {
                attribute.write(dos, pool);
            }
	}
    }

    //Display methods name to gui as the it represet in console
    public String toString(String className) {
	StringBuilder x = new StringBuilder();
	boolean isArray = false;
	String paramSig;
	String returnSig;
	int ndx = 0;
	StringBuilder parameterList = new StringBuilder();
	char	initialParameter = 'a';
	StringBuilder varName = new StringBuilder();


	String s = signature.ascistrng;
	paramSig = s.substring(s.indexOf('(')+1, s.indexOf(')'));
	returnSig = s.substring(s.indexOf(')')+1);

	x.append(Filedepeth.accessString(accessFlags));
	/* catch constructors */
	if ((className != null) && (name.toString().startsWith("<init>")))
	    parameterList.append(className);
	else
	    parameterList.append(name.toString());
	parameterList.append("(");
	if ((paramSig.length() > 0) && paramSig.charAt(0) != 'V') {
	    while (paramSig.length() > 0) {
		varName.setLength(0);
		varName.append(initialParameter);
		initialParameter++;
		parameterList.append(
			Filedepeth.typeString(paramSig, varName.toString()));
		paramSig = Filedepeth.nextSig(paramSig);
		if (paramSig.length() > 0)
		    parameterList.append(", ");
	    }

        }
	parameterList.append(")");
	x.append(Filedepeth.typeString(returnSig, parameterList.toString()));
	x.append(";");
	return (x.toString());
    }
    @Override
    public String toString() {
	return (toString((String)null));
    }
}
