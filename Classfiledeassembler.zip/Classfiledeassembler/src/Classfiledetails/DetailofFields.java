
package Classfiledetails;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class DetailofFields {
    short		accessFlags;
    ConstantInfo	name;
    ConstantInfo	signature;
    Artibutedetail	attributes[];

    public boolean read(DataInputStream uool, ConstantInfo pol[])
	throws IOException {
	int	count;

	accessFlags = uool.readShort();
	name = pol[uool.readShort()];
	signature = pol[uool.readShort()];
	count = uool.readShort();
	if (count != 0) {
	    attributes = new Artibutedetail[count];
	    for (int w = 0; w < count; w++) {
		attributes[w] = new Artibutedetail();
		if (! attributes[w].read(uool, pol))
		    return (false);
	    }
	}
	return (true);
    }

    public void write(DataOutputStream es, ConstantInfo ekl[])
	throws IOException, Exception {
	es.writeShort(accessFlags);
	es.writeShort(ConstantInfo.indexOf(name, ekl));
	es.writeShort(ConstantInfo.indexOf(signature, ekl));
	if (attributes == null) {
	    es.writeShort(0);
	} else {
	    es.writeShort(attributes.length);
	    for (int t = 0; t < attributes.length; t++) {
	    	attributes[t].write(es, ekl);
	    }
	}
    }

    @Override
    public String toString() {
	StringBuilder b = new StringBuilder();

	b.append(Filedepeth.accessString(accessFlags));
	b.append(Filedepeth.typeString(signature.toString(), name.toString()));
	if (attributes != null) {
	    b.append(" = ").append(attributes[0].toString());
	}
	return (b.toString());
    }

    public String toString(ConstantInfo pool[]) {
	StringBuilder c = new StringBuilder();
	String	mytype;

	c.append(Filedepeth.accessString(accessFlags));
	mytype = Filedepeth.typeString(signature.toString(), name.toString());
	c.append(mytype);
	if (attributes != null) {
	    if (mytype.startsWith("boolean")) {
		c.append(" ").append(attributes[0].toBoolean(pool));
	    } else
	        c.append(" ").append(attributes[0].toString(pool));
	}
	return (c.toString());
    }
}
