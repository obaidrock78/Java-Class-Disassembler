


package Classfiledetails;

import java.io.*;


public class Filedepeth {
    int star;
    short sor;
    short mor;
    ConstantInfo qol[];
    short nf;
    ConstantInfo	aq;
    ConstantInfo	pl;
    ConstantInfo it[];
    DetailofFields		   [] z;
    Detailofmethods		   [] m;
    Artibutedetail	   [] k;
    boolean		        o = false;

    public static final int pob 		= 0x1;
    public static final int ac 	= 0x2;
    public static final int ap 	= 0x4;
    public static final int stats 		= 0x8;
    public static final int full 		= 0x10;
    public static final int sycn 	= 0x20;
    public static final int ts 	= 0x40;
    public static final int trensit 	= 0x80;
    public static final int sp 		= 0x100;
    public static final int interfacee 	= 0x200;
    public static final int abst 	= 0x400;

    public boolean db = false;
    public boolean dbcnts;

    public Filedepeth() {
        this.dbcnts = false;
    }
    //Read .Class file from the filechosser  path selector input stream lp  
    public boolean read(InputStream lp)
	throws IOException {
	    DataInputStream di = new DataInputStream(lp);
    	int	count;

	    star = di.readInt();
	    if (star != (int) 0xCAFEBABE) {
	        return (false);
	    }

	    sor = di.readShort();
	    mor = di.readShort();
	    count = di.readShort();
	    qol = new ConstantInfo[count];
	    if (db)
	        System.out.println("read(): Read header...");
	    qol[0] = new ConstantInfo();
	    for (int i = 1; i < qol.length; i++) {
	        qol[i] = new ConstantInfo();
	        if (! qol[i].read(di)) {
		        return (false);
	        }
	        // These two types take up "two" spots in the table
	        if ((qol[i].itemtype == ConstantInfo.Intlong) ||
	    	    (qol[i].itemtype == ConstantInfo.DddOUBLE))
		        i++;
	    }

	    /*
	     * Update pointers in the constant table. This turns the
 	     * table into a real datastructure.
 	     *
	     * TODO: Have it verify that the right arguments are present
 	     */
	    for (int i = 1; i < qol.length; i++) {
	        if (qol[i] == null)
		        continue;
	        if (qol[i].index1 > 0)
	        	qol[i].firstarg = qol[qol[i].index1];
	        if (qol[i].index2 > 0)
		        qol[i].secondargs = qol[qol[i].index2];
	    }

	    if (dbcnts) {
	        for (int i = 1; i < qol.length; i++) {
		        System.out.println("C"+i+" - "+qol[i]);
	        }
  	    }
	    nf = di.readShort();

	    aq = qol[di.readShort()];
	    pl = qol[di.readShort()];
	    if (db)
	        System.out.println("read(): Read class info...");

    	//Now this code will code will identify all the implements in the .class file
            
	    count = di.readShort();
	    if (count != 0) {
	        if (db)
	            System.out.println("Class implements "+count+" interfaces.");
	        it = new ConstantInfo[count];
	        for (int i = 0; i < count; i++) {
		        int iindex = di.readShort();
		        if ((iindex < 1) || (iindex > qol.length - 1))
		            return (false);
		        it[i] = qol[iindex];
		        if (db)
		            System.out.println("I"+i+": "+it[i]);
	        }
	    }
	    if (db)
	        System.out.println("read(): Read interface info...");

    	//Identify all the fields in the code
    	count = di.readShort();
    	if (db)
    	    System.out.println("This class has "+count+" fields.");
    	if (count != 0) {
	        z = new DetailofFields[count];
	        for (int i = 0; i < count; i++) {
        		z[i] = new DetailofFields();
	        	if (! z[i].read(di, qol)) {
		           return (false);
        		}
	        	if (db)
        		    System.out.println("F"+i+": "+
			    		z[i].toString(qol));
	        }
	    }
	    if (db)
	        System.out.println("read(): Read field info...");

	 
            //This methodcode  will identify all the methods in the class file
            count = di.readShort();
	    if (count != 0) {
	        m = new Detailofmethods[count];
	        for (int i = 0; i < count; i++) {
		        m[i] = new Detailofmethods();
		        if (! m[i].read(di, qol)) {
		            return (false);
	    	    }
	    	    if (db)
	    	        System.out.println("M"+i+": "+m[i].toString());
	        }
    	}
	    if (db)
	        System.out.println("read(): Read method info...");


    	//Identify all the artibutes in .class file and then add in artibute array
    	count = di.readShort();
    	if (count != 0) {
    	    k = new Artibutedetail[count];
    	    for (int i = 0; i < count; i++) {
    		    k[i] = new Artibutedetail();
    		    if (! k[i].read(di, qol)) {
    		        return (false);
    		    }
    	    }
    	}
	    if (db) {
	        System.out.println("read(): Read attribute info...");
	        System.out.println("done.");
	    }
	    o = true;
	    return(true);
    }

  
    
    //In this output stream as from input stream the same is out put the in put stream input and mainpulate the class file this methods save a
    //all of it in out outstream that lo
    
    
    
    
    
    public void write(OutputStream lo)
	throws IOException, Exception {
	    DataOutputStream dos = new DataOutputStream(lo);

	    if (! o) {
	        throw new Exception("ClassFile::write() - Invalid Class");
	    }

	    dos.writeInt(star);
	    dos.writeShort(sor);
	    dos.writeShort(mor);
	    dos.writeShort(qol.length);
	    for (int i = 1; i < qol.length; i++) {
	        if (qol[i] != null)
	            qol[i].write(dos, qol);
	    }
	    dos.writeShort(nf);
	    dos.writeShort(ConstantInfo.indexOf(aq, qol));
	    dos.writeShort(ConstantInfo.indexOf(pl, qol));

	    if (it == null) {
	        dos.writeShort(0);
	    } else {
	        dos.writeShort(it.length);
                for (ConstantInfo it1 : it) {
                    dos.writeShort(ConstantInfo.indexOf(it1, qol));
                }
	    }

	    if (z == null) {
	        dos.writeShort(0);
	    } else {
	        dos.writeShort(z.length);
                for (DetailofFields z1 : z) {
                    z1.write(dos, qol);
                }
	    }

	    if (m == null) {
	        dos.writeShort(0);
	    } else {
	        dos.writeShort(m.length);
                for (Detailofmethods m1 : m) {
                    m1.write(dos, qol);
                }
	    }

	    if (k == null) {
	        dos.writeShort(0);
	    } else {
	        dos.writeShort(k.length);
                for (Artibutedetail k1 : k) {
                    k1.write(dos, qol);
                }
	    }
    }

    
    //As it create a strings that show wht access flags set for
   // So 0x14 returns public final in the output
     //* @param flags
     //* @return 
     
    public static String accessString(short az) {
	    StringBuilder x = new StringBuilder();

	    if ((az & pob) != 0) {
	        x.append("public ");
	    }

	    if ((az & ac) != 0) {
	        x.append("private ");
	    }

	    if ((az & ap) != 0) {
	        x.append("protected ");
	    }

	    if ((az & stats) != 0) {
	        x.append("static ");
	    }

	    if ((az & full) != 0) {
	        x.append("final ");
	    }

	    if ((az & sycn) != 0) {
	        x.append("synchronized ");
	    }

	    if ((az & ts) != 0) {
	        x.append("threadsafe ");
	    }

	    if ((az & trensit) != 0) {
	        x.append("transient ");
	    }

	    if ((az & sp) != 0) {
	        x.append("native ");
	    }

	    if ((az & interfacee) != 0) {
	        x.append("interface ");
	    }

	    if ((az & abst) != 0) {
	        x.append("abstract ");
	    }

	    return (x.toString());
    }

    
    // It will show how the variable itemname will be represented in th output
      //As an expample the variable "[C" and "myArray" will
      //return the string "char myArray[]"
      //@param typeString
     
    public static String typeString(String typeString, String varName) {
	    int isArray = 0;
	    int	ndx = 0;
	    StringBuilder r = new StringBuilder();

	    while (typeString.charAt(ndx) == '[') {
	        isArray++;
	        ndx++;
	    }

	    switch (typeString.charAt(ndx)) {
	        case 'B' :
		        r.append("byte ");
		        break;
	        case 'C' :
		        r.append("char ");
		        break;
	        case 'D' :
		        r.append("double ");
		        break;
	        case 'F' :
		        r.append("float ");
		        break;
	        case 'I' :
		        r.append("int ");
		        break;
	        case 'J' :
		        r.append("long ");
		        break;
	        case 'L' :
		        for (int i = ndx+1; i < typeString.indexOf(';'); i++) {
		            if (typeString.charAt(i) != '/')
			            r.append(typeString.charAt(i));
		            else
			        r.append('.');
		        }
		        r.append(" ");
		        break;
	        case 'V':
		        r.append("void ");
		        break;
	        case 'S' :
		        r.append("short ");
		        break;
	        case 'Z' :
		        r.append("boolean ");
		        break;
	    }
	    r.append(varName);
	    while (isArray > 0) {
	        r.append("[]");
	        isArray--;
	    }
	    return (r.toString());
    }

    // Returns next sig of a string of concat signatures as in the input of class file 
    //  As an example if the sig was BII, this method would give in return the  value II
     
    public static String nextSig(String sig) {
	    int	ndx = 0;
	    String 	x;

	    while (sig.charAt(ndx) == '[')
	        ndx++;

	    if (sig.charAt(ndx) == 'L') {
	        while (sig.charAt(ndx) != ';')
		        ndx++;
	    }
	    ndx++;
	    x =  (sig.substring(ndx));
	    return (x);
    }

    // print the itemname of the file conacail form as reprensented in gui
    private String printClassName(String s) {
	    StringBuffer x;

	    if (s.charAt(0) == '[') {
	        return(typeString(s, ""));
	    }

	    x = new StringBuffer();
	    for (int j = 0; j < s.length(); j++) {
	        if (s.charAt(j) == '/')
	    	    x.append('.');
	        else
	    	    x.append(s.charAt(j));
	    }
	    return (x.toString());

    }

    public String getClassName() {
    	return printClassName(aq.firstarg.ascistrng);
    }

    /**
    The old display with tostring to GUI
     * @return 
     */
    @Override
    public String toString() {
	    return("Class File (Version "+sor+"."+mor+
	        ") for class "+aq.firstarg);
    }

    /**
    Display  all the information gathered in class file to the GUI Text Area
     * @param rb
     * @throws java.lang.Exception
     */
    public void display(PrintStream rb)
	throws Exception {
	    int i;
	    String myClassName;
	    String mySuperClassName;
	    String packageName = null;

	    if (! o) {
	        rb.println("Not a valid class");
	    }

	    myClassName = printClassName(aq.firstarg.ascistrng);
	    mySuperClassName = printClassName(pl.firstarg.ascistrng);
	    if (myClassName.indexOf('.') > 0) {
	        packageName =
		        myClassName.substring(0, myClassName.lastIndexOf('.'));
	        myClassName = myClassName.substring(myClassName.lastIndexOf('.')+1);
	        rb.println("package "+packageName+"\n");
	    }

	    for (i = 1; i < qol.length; i++) {
	        if (qol[i] == null)
		        continue;
	        if ((qol[i] == aq) ||
		        (qol[i] == pl))
		        continue;
	        if (qol[i].itemtype == ConstantInfo.PLRS) {
		        String s = qol[i].firstarg.ascistrng;
		            if (s.charAt(0) == '[')
		                continue;
		        s = printClassName(qol[i].firstarg.ascistrng);
		        if ((packageName != null) && (s.startsWith(packageName)))
		            continue;
		        rb.println("import "+printClassName(s)+";");
	        }
	    }
	    rb.println();
	    rb.println("/*");
	    DataInputStream dis;
	    ConstantInfo cpi;

	    if (k != null) {
	        rb.println(" * This class has "+k.length+
					" optional class attributes.");
	        rb.println(" * These attributes are: ");
	        for (i = 0; i < k.length; i++) {
	            String attrName = k[i].name.ascistrng;
	            dis = new DataInputStream(new ByteArrayInputStream(k[i].data));

	            rb.println(" * Attribute "+(i+1)+" is of type "+k[i].name);
	            if (attrName.compareTo("SourceFile") == 0) {
		            cpi = null;
		            try {
		                cpi = qol[dis.readShort()];
		            } catch (IOException e) { }
		            rb.println(" *	SourceFile : "+cpi);
	            } else {
		            rb.println(" *	TYPE ("+attrName+")");
	            }
            }
	    } else {
	        rb.println(" * This class has NO optional class attributes.");
	    }
	    rb.println(" */\n");
	    rb.print(accessString(nf)+"class "+myClassName+" extends "+
		    mySuperClassName);
	    if (it != null) {
	        rb.print(" implements ");
	        for (i = 0; i < it.length - 1; i++) {
	    	    rb.print(it[i].firstarg.ascistrng+", ");
	        }
	        rb.print(it[it.length-1].firstarg.ascistrng);
	    }
	    rb.println(" {\n");
	    if (z != null) {
	        rb.println("/* Instance Variables */");
	        for (i = 0; i < z.length; i++) {
	            rb.println(z[i].toString(qol)+"    "+";");
	        }
	    }

	    if (m != null) {
	        rb.println("\n/* Methods */");
	        for (i = 0; i < m.length; i++) {
	            rb.println("    "+m[i].toString(myClassName));
	        }
	    }
	    rb.println("\n}");
    }

    public ConstantInfo getConstantRef(short index) {
	    return (qol[index]);
    }

    /**
     *As this methods adds a single item from the constant pool class and if the items already added then it will be notifed by the pointer
     * @param loopp
     * @return 
     * @throws java.lang.Exception 
     */
    public short addConstantPoolItem(ConstantInfo loopp)
	throws Exception {
	    ConstantInfo newConstantPool[];
	    ConstantInfo cp;

	    cp = loopp.inPool(qol);
	    if (cp != null)
	        return ConstantInfo.indexOf(cp, qol);

	    newConstantPool = new ConstantInfo[qol.length+1];
        System.arraycopy(qol, 1, newConstantPool, 1, qol.length - 1);
	    newConstantPool[qol.length] = loopp;
	    qol = newConstantPool;
	    return ConstantInfo.indexOf(loopp, qol);
    }

   
    
    
    
    
    
    
    
    /*
    
    The set of rules is simple, first perceive pool objects containing
    constants withinside the listing of objects to be delivered which can be already
    withinside the regular pool. If any are discovered to already exist, change
    the suggestions withinside the non-regular objects to factor to those in
    the pool as opposed to those withinside the listing.Add a few objects to the regular pool.
    This is used to feature new objects to the regular pool. 
    The objects references in firstarg, secondargs are anticipated to be legitimate suggestions .
    Printing is performed to save you including redundant objects to the listing and to hold string space.

            Next test to see
                if any of the non-regular objects are already withinside the pool and
                    in that case restoration up the others withinside the listing to factor to those in
                        the pool. Finally, upload any objects (there should be as a minimum one) from the object listing that aren't already withinside the pool, all of

    
    
   
    
    
    
    
    */
    
    
    
    
    
    public void addConstantPoolItems(ConstantInfo jjj[]) {
	    ConstantInfo newArg;
	    ConstantInfo newConstantPool[];
	    boolean delete[] = new boolean[jjj.length];

	    /* Step one, look for matching constants */
	    for (int j = 0; j < jjj.length; j++) {
	        if ( (jjj[j].itemtype == ConstantInfo.ASCI) ||
	             (jjj[j].itemtype == ConstantInfo.UNIDE) ||
	             (jjj[j].itemtype == ConstantInfo.ING) ||
	             (jjj[j].itemtype == ConstantInfo.Intlong) ||
	             (jjj[j].itemtype == ConstantInfo.Floatdouble) ||
	             (jjj[j].itemtype == ConstantInfo.DddOUBLE)) {

		    //See this item as jjj for constant pool
		    delete[j] = false;
		    newArg = jjj[j].inPool(qol);
		    if (newArg != null) {
		        // remove the reference at last
		        delete[j] = true;	// point it for  deletion
                        for (ConstantInfo jjj1 : jjj) {
                            if (jjj1.firstarg == jjj[j]) {
                                jjj1.firstarg = newArg;
                            }
                            if (jjj1.secondargs == jjj[j]) {
                                jjj1.secondargs = newArg;
                            }
                        }
		        }
	        }
	    }

    	//Second step :to match all the things else 
    	for (int j = 0; j < jjj.length; j++) {
    	    if ( (jjj[j].itemtype == ConstantInfo.PLRS) ||
	             (jjj[j].itemtype == ConstantInfo.FIELDREFFERENCE) ||
	             (jjj[j].itemtype == ConstantInfo.METHREF) ||
	             (jjj[j].itemtype == ConstantInfo.STRNEGS) ||
	             (jjj[j].itemtype == ConstantInfo.INTERFACEtofile) ||
	             (jjj[j].itemtype == ConstantInfo.NAMETYPE)) {

		    // Looking  for specfic item in the jjj
		    delete[j] = false;
		    newArg = jjj[j].inPool(qol);
		    if (newArg != null) {
		        // remove the references in the list.
		        delete[j] = true;	// point it for deletion
                        for (ConstantInfo jjj1 : jjj) {
                            if (jjj1.firstarg == jjj[j]) {
                                jjj1.firstarg = newArg;
                            }
                            if (jjj1.secondargs == jjj[j]) {
                                jjj1.secondargs = newArg;
                            }
                        }
		        }
	        }
	    }

    	// third step: Add the surviving items to the pool //
    	int count = 0;
    	for (int i = 0; i < jjj.length; i++) {
    	    if (! delete[i])
        		count++;
	    }
    	// count == # of survivors
    	newConstantPool = new ConstantInfo[qol.length + count];
        System.arraycopy(qol, 1, newConstantPool, 1, qol.length - 1); // newConstantPool == existing qol

    	int ndx = 0;
    	for (int i = qol.length; i < newConstantPool.length; i++) {
	        while (delete[ndx])
        		ndx++;
    	    newConstantPool[i] = jjj[ndx];
	        ndx++;
	    }
    	// newConstantPool == existing + new
	    qol = newConstantPool;
	    // all done.
    }

    //
     
     
     // jjj is an array of constant pool items that are first added
     // to array. At a minimum jjj[0] must be an ascii
     // item with the itemname of the attribute. 
    public void addAttribute(Artibutedetail newart) {

	    if (k == null) {
	        k = new Artibutedetail[1];
	        k[0] = newart;
	    } else {
	        Artibutedetail newAttrList[] = new Artibutedetail[1+k.length];
                System.arraycopy(k, 0, newAttrList, 0, k.length);
	        newAttrList[k.length] = newart;
	        k = newAttrList;
	    }
    }

    
     // Return class file containg artibute names as newart
     
    public Artibutedetail getAttribute(String name) {
	    if (k == null)
	        return null;
        for (Artibutedetail k1 : k) {
            if (name.compareTo(k1.name.toString()) == 0) {
                return k1;
            }
        }
	    return (null);
    }

   //As if someone call this methods from other class it will return constant pool items
    public ConstantInfo getConstantPoolItem(short index)
	throws Exception {
	    ConstantInfo cp;

	    if ((index <= 0) || (index > (qol.length - 1)))
	        return (null);
	    cp = qol[index];
	    if (cp.firstarg != null)
	        cp.index1 = ConstantInfo.indexOf(cp.firstarg, qol);
	    if (cp.secondargs != null)
	        cp.index2 = ConstantInfo.indexOf(cp.secondargs, qol);
	    return cp;
    }

  
    public void mapClass(String oldClass, String newClass) {
	    if (db)
	        System.out.println("Mapping class name "+oldClass+" ==> "+
			    newClass+" for class "+aq.firstarg);
        for (ConstantInfo qol1 : qol) {
            if (qol1.itemtype == ConstantInfo.PLRS) {
                String cname = qol1.firstarg.ascistrng;
                if (cname.compareTo(oldClass) == 0) {
                    if (db) {
                        System.out.println("REPLACING "+cname+" with "+newClass);
                    }
                    qol1.firstarg.ascistrng = newClass;
                }
            }
        }
    }

   
     public void mapPackage(String oldPackage, String newPackage) {
        for (ConstantInfo qol1 : qol) {
            if (qol1.itemtype == ConstantInfo.PLRS) {
                String cname = qol1.firstarg.ascistrng;
                if (cname.startsWith(oldPackage)) {
                    qol1.firstarg.ascistrng = newPackage +
                            cname.substring(cname.lastIndexOf('/'));
                }
            }
        }
    }

   
    public void deleteMethod(String name, String signature) {
        for (ConstantInfo qol1 : qol) {
            if (qol1.itemtype == ConstantInfo.PLRS) {
            }
        }
    }
}
