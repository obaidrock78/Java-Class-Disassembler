
package Classfiledetails;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MainController {
    
    @FXML
    private TextArea console;
    private PrintStream ps ;
    public void initialize() {
        ps = new PrintStream(new Console(console)) ;
    }
    public void button(ActionEvent event) {
        
    }
    public class Console extends OutputStream {
        private final TextArea console;
        public Console(TextArea console) {
            this.console = console;
        }
        public void appendText(String valueOf) {
            Platform.runLater(() -> console.appendText(valueOf));
        }
        @Override
        public void write(int u) throws IOException {
            appendText(String.valueOf((char)u));
        }
    }
public String s;
@FXML
        public TextField c;
	
    @FXML
    private Font x1;
    

    @FXML
    private Color x2;

    @FXML
    private Font x3;
@FXML
	public Button btn1, btn2;
	@FXML
	public ListView listview;
@FXML
        public TextField abc;
	
Filedepeth cf = new Filedepeth();
	
	public void Button1Action(ActionEvent event) {
            console.clear();
		FileChooser fc = new FileChooser();
		fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Class Files", "*.class"));
		File selectedFile = fc.showOpenDialog(null);
		
		if(selectedFile != null) {
		
                    try {
           
             
	FileInputStream fi = new FileInputStream(selectedFile.getAbsolutePath());
	
      

	if (! cf.read(fi)) {
	    System.out.println("Unable to read class file.");
	    System.exit(1);
	}
	
        
  
          
          
          
          
          
          
          cf.display(ps);
          
          
          
          
          
	} catch (Exception e) {}
    }
		
                    
                    
                
		
else {
			System.out.println("File is not valid!");
		}
        }
	

    @FXML
    private Color x4;

    public void Bob() {
        
        
        
        
        
    }
    public void close(ActionEvent event) {
        
         ((Stage)(((Button)event.getSource()).getScene().getWindow())).close();
        
        
        
        
        
        
    }
    public void save(ActionEvent event) {
        
    
}
}