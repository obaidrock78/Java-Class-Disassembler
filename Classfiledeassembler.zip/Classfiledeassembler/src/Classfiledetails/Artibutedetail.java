
package Classfiledetails;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Artibutedetail {
    ConstantInfo	name;	// attributes item name by other classes
    byte		data[]; // attributes data by other classes

    public Artibutedetail(ConstantInfo newName, byte newData[]) {
	name = name;
	data = newData;
    }

    public Artibutedetail() {
    }

    public boolean read(DataInputStream qwe, ConstantInfo pool[])
	throws IOException {
	int len;

	name = pool[qwe.readShort()];
	len = qwe.readInt();
	data = new byte[len];
	len  = qwe.read(data);
	if (len != data.length)
	    return (false);
	return (true);
    }

    public void write(DataOutputStream jol, ConstantInfo pool[])
	throws IOException, Exception {
	jol.writeShort(ConstantInfo.indexOf(name, pool));
	jol.writeInt(data.length);
	jol.write(data, 0, data.length);
    }

    short indexFromBytes(byte v[]) {
	return (short)(((v[0] << 8) & (0xff << 8)) |
		       ((v[1] << 0) & (0xff << 0)));
    }

    public String toString(ConstantInfo qooll[]) {
	StringBuilder x = new StringBuilder();
	String type = name.toString();
	ConstantInfo item;

	if (type.compareTo("ConstantValue") == 0) {
	    item = qooll[indexFromBytes(data)];
	    return (item.toString());
	} else if (type.compareTo("SourceFile") == 0) {
	    item = qooll[indexFromBytes(data)];
	    return (item.toString());
	} else {
	    x.append(type).append("<").append(data.length).append(" bytes>");
	}
	return (x.toString());
    }

    public String toBoolean(ConstantInfo pool[]) {
	ConstantInfo item = pool[indexFromBytes(data)];

	if (item.integerval == 0)
	    return ("= false");
	return ("= true");
    }

    @Override
    public String toString() {
	return (name.toString()+" <"+data.length+" bytes>");
    }
}
