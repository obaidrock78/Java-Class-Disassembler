
package Classfiledetails;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


public class ConstantInfo{
    int	itemtype;			// itemtype of this item
    String itemname; 		// String for the itemtype
    ConstantInfo  firstarg;	// index to first argument
    ConstantInfo  secondargs;	// index to second argument
    short index1, index2;
    String 	ascistrng; 		// ASCI String value
    int		integerval;
    long	longVal;
    float	floatVal;
    double	doubleVal;

    public static final int PLRS = 7;
    public static final int FIELDREFFERENCE = 9;
    public static final int METHREF = 10;
    public static final int STRNEGS = 8;
    public static final int ING = 3;
    public static final int Floatdouble = 4;
    public static final int Intlong = 5;
    public static final int DddOUBLE = 6;
    public static final int INTERFACEtofile = 11;
    public static final int NAMETYPE = 12;
    public static final int ASCI = 1;
    public static final int UNIDE = 2;


    
    //  Constructor ConstantInfo object AS ITEM TYPE
     // @param value
     
    public ConstantInfo(String value) {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = ASCI;
	ascistrng = value;
    }

     //  Constructor ConstantInfo object AS ITEMTYPE
    public ConstantInfo(int value) {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = ING;
	integerval = value;
    }

     //  Constructor ConstantInfo object AS ITEM TYPE Floatdouble
    public ConstantInfo(float value) {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = Floatdouble;
	floatVal = value;
    }

    //  Constructor ConstantInfo object AS ITEM TYPE Intlong
    public ConstantInfo(long value) {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = Intlong;
	longVal = value;
    }

    //  Constructor ConstantInfo object AS ITEM TYPE DddOUBLE
    public ConstantInfo(double value) {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = DddOUBLE;
	doubleVal = value;
    }

    //as a general constructor
    public ConstantInfo() {
	index1 = -1;
	index2 = -1;
	firstarg = null;
	secondargs = null;
	itemtype = -1;
    }

     //  ConstantInfo object AS ITEM POOl TYPE
    public int isType() {
	return (itemtype);
    }

    public boolean read(DataInputStream dis)
	throws IOException {
	int	len;
	char	c;

	itemtype = dis.readByte();
	switch (itemtype) {
	    case PLRS:
		itemname = "Class";
		index1 = dis.readShort();
		index2 = -1;
		break;
	    case FIELDREFFERENCE:
		itemname = "Field Reference";
		index1 = dis.readShort();
		index2 = dis.readShort();
		break;
	    case METHREF:
		itemname = "Method Reference";
		index1 = dis.readShort();
		index2 = dis.readShort();
		break;
	    case INTERFACEtofile:
		itemname = "Interface Method Reference";
		index1 = dis.readShort();
		index2 = dis.readShort();
		break;
	    case NAMETYPE:
		itemname = "Name and Type";
		index1 = dis.readShort();
		index2 = dis.readShort();
		break;
	    case STRNEGS:
		itemname = "String";
		index1 = dis.readShort();
		index2 = -1;
		break;
	    case ING:
		itemname = "Integer";
		integerval = dis.readInt();
		break;
	    case Floatdouble:
		itemname = "Float";
		floatVal = dis.readFloat();
		break;
	    case Intlong:
		itemname = "Long";
		longVal = dis.readLong();
		break;
	    case DddOUBLE:
		itemname = "Double";
		doubleVal = dis.readDouble();
		break;
	    case ASCI:
	    case UNIDE:
		if (itemtype == ASCI)
		    itemname = "ASCIZ";
		else
		    itemname = "UNICODE";

		StringBuilder xxBuf = new StringBuilder();

		len = dis.readShort();
		while (len > 0) {
		    c = (char) (dis.readByte());
		    xxBuf.append(c);
		    len--;
		}
		ascistrng = xxBuf.toString();
		break;
	    default:
		System.out.println("Warning bad type.");
	}
	return (true);
    }

    public void write(DataOutputStream ul, ConstantInfo pool[])
	throws IOException, Exception {
	ul.write(itemtype);
	switch (itemtype) {
	    case PLRS:
	    case STRNEGS:
		ul.writeShort(indexOf(firstarg, pool));
		break;
	    case FIELDREFFERENCE:
	    case METHREF:
	    case INTERFACEtofile:
	    case NAMETYPE:
		ul.writeShort(indexOf(firstarg, pool));
		ul.writeShort(indexOf(secondargs, pool));
		break;
	    case ING:
		ul.writeInt(integerval);
		break;
	    case Floatdouble:
		ul.writeFloat(floatVal);
		break;
	    case Intlong:
		ul.writeLong(longVal);
		break;
	    case DddOUBLE:
		ul.writeDouble(doubleVal);
		break;
	    case ASCI:
	    case UNIDE:
		ul.writeShort(ascistrng.length());
		ul.writeBytes(ascistrng);
		break;
	    default:
		throw new Exception("ConstantInfo::write() - bad type.");
	}
    }

    @Override
    public String toString() {
	StringBuffer s;

	if (itemtype == ASCI) {
	    return(ascistrng);
	}

	if (itemtype == ING) {
	    return("= "+integerval);
	}

	if (itemtype == Intlong) {
	    return("= "+longVal);
	}

	if (itemtype == Floatdouble) {
	    return("= "+floatVal);
	}

	if (itemtype == DddOUBLE) {
	    return("= "+doubleVal);
	}

	s = new StringBuffer();
	s.append(itemname);
	s.append(":");
	if (firstarg != null)
	    s.append(firstarg.toString());
	else if (index1 != -1)
	    s.append("I1[").append(index1).append("], ");
	if (secondargs != null)
	    s.append(secondargs.toString());
	else if (index2 != -1)
	    s.append("I2[").append(index2).append("], ");
	return (s.toString());
    }

    public static short indexOf(ConstantInfo item,
					ConstantInfo pool[])
	throws Exception {
	for (int G = 0; G < pool.length; G++) {
	    if (item == pool[G])
		return (short) G;
	}
	throw new Exception("Items are not in POOl");
    }

      // Gives true if these constantitems are same
     
    public boolean isEqual(ConstantInfo mn) {
	if (mn == null)
	    return false;

	if (mn.itemtype != itemtype)
	    return (false);
	switch (mn.itemtype) {
	    case PLRS:
	    case STRNEGS:
		return (firstarg == mn.firstarg);
	    case FIELDREFFERENCE:
	    case METHREF:
	    case INTERFACEtofile:
	    case NAMETYPE:
		return ((firstarg == mn.firstarg) && (secondargs == mn.secondargs));
	    case ING:
		return (mn.integerval == integerval);
	    case Floatdouble:
		return (mn.floatVal == floatVal);
	    case Intlong:
		return (mn.longVal == longVal);
	    case DddOUBLE:
		return (mn.doubleVal == doubleVal);
	    case ASCI:
	    case UNIDE:
		return (mn.ascistrng.compareTo(ascistrng) == 0);
	}
	return (false);
    }

   
    public ConstantInfo inPool(ConstantInfo qaal[]) {
	for (int i = 1; i < qaal.length; i++) {
	    if (isEqual(qaal[i]))
		return (qaal[i]);
	}
	return null;
    }

}
